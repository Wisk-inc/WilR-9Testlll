"""
WilR-9 runner wrapper (Spectra Team)

This script provides a simple text-only prompt loop for WilR-9.
It will attempt to call a `respond(prompt)` function from common entrypoint files
(`main.py`, `app.py`, `server.py`) if available. If not found, it will echo the prompt
as a placeholder so the interface works in Colab.

Usage:
    python WilR-9_run.py
"""
import importlib
import sys, os

POSSIBLE = ["main", "app", "server"]
respond_fn = None
mod_name = None

for name in POSSIBLE:
    try:
        if os.path.exists(name + ".py"):
            mod = importlib.import_module(name)
            if hasattr(mod, "respond") and callable(mod.respond):
                respond_fn = mod.respond
                mod_name = name
                break
            # Try common class-based interface
            if hasattr(mod, "Model") :
                try:
                    model = getattr(mod, "Model")()
                    if hasattr(model, "respond"):
                        respond_fn = model.respond
                        mod_name = name + ".Model"
                        break
                except Exception:
                    pass
    except Exception:
        continue

print("WilR-9 runner (Spectra Team)")
if mod_name:
    print("Using respond from:", mod_name)
else:
    print("No respond() found in main/app/server. Falling back to echo placeholder.")

try:
    while True:
        prompt = input("Enter query (or 'exit' to quit): ").strip()
        if prompt.lower() in ("exit","quit"):
            print("Goodbye.")
            break
        if respond_fn:
            try:
                out = respond_fn(prompt)
                print("WilR-9:", out)
            except Exception as e:
                print("Error when calling respond():", e)
                print("WilR-9 (fallback):", prompt)
        else:
            # Placeholder behaviour — echo back the prompt
            print("WilR-9:", prompt)
except KeyboardInterrupt:
    print("\\nInterrupted, exiting.")
