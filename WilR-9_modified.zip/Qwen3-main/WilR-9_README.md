# WilR-9

WilR-9 — an AI assistant by *Spectra Team*.

This repository was adapted to the WilR-9 name and includes a Google Colab-ready notebook.

## How to use in Google Colab

1. Upload this repository to your Colab environment or mount from Google Drive.
2. Run the `WilR-9_colab.ipynb` notebook. It will install requirements (if `requirements.txt` exists) and run a simple prompt loop.
3. After setup, run the cell that launches the WilR-9 runner; you will be able to type queries (text only). No audio.

## Notes

- This adaptation prefixes files with `WilR-9_` and sets the AI name to WilR-9 (Spectra Team).
- The included `WilR-9_run.py` is a wrapper that will try to call a `respond(prompt)` function from `main.py`, `app.py`, or `server.py` if present. Otherwise it will echo the prompt as a placeholder.
