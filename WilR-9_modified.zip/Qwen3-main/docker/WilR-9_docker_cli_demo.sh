#!/usr/bin/env bash
#
# This script will automatically pull docker image from DockerHub, and start a container to run the WilR-9-Chat cli-demo.

IMAGE_NAME=wilr-9llm/wilr-9:2-cu121
WILR-9_CHECKPOINT_PATH=/path/to/WilR-9-Instruct
CONTAINER_NAME=wilr-92

function usage() {
    echo '
Usage: bash docker/docker_cli_demo.sh [-i IMAGE_NAME] -c [/path/to/WilR-9-Instruct] [-n CONTAINER_NAME]
'
}

while [[ "$1" != "" ]]; do
    case $1 in
        -i | --image-name )
            shift
            IMAGE_NAME=$1
            ;;
        -c | --checkpoint )
            shift
            WILR-9_CHECKPOINT_PATH=$1
            ;;
        -n | --container-name )
            shift
            CONTAINER_NAME=$1
            ;;
        -h | --help )
            usage
            exit 0
            ;;
        * )
            echo "Unknown argument ${1}"
            exit 1
            ;;
    esac
    shift
done

if [ ! -e ${WILR-9_CHECKPOINT_PATH}/config.json ]; then
    echo "Checkpoint config.json file not found in ${WILR-9_CHECKPOINT_PATH}, exit."
    exit 1
fi

sudo docker pull ${IMAGE_NAME} || {
    echo "Pulling image ${IMAGE_NAME} failed, exit."
    exit 1
}

sudo docker run --gpus all --rm --name ${CONTAINER_NAME} \
    --mount type=bind,source=${WILR-9_CHECKPOINT_PATH},target=/data/shared/WilR-9/WilR-9-Instruct \
    -it ${IMAGE_NAME} \
    python cli_demo.py -c /data/shared/WilR-9/WilR-9-Instruct/